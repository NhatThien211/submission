/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student;

import com.practicalexam.student.data.Watch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * @author ADMIN
 */
public class Cabinet {

    //StartList
    // Declare ArrayList or Array here
    static List<Watch> listWatch = new ArrayList<>();
    static Watch[] arr = new Watch[10];
    //EndList
    Scanner scannerObj = new Scanner(System.in);


    public void add() {
        // Print the object details after adding
        System.out.println("Add a watch to the list");
        System.out.println("Input Id : ");
        String id = scannerObj.nextLine();
        System.out.println("Input Name : ");
        scannerObj = new Scanner(System.in);
        String name = scannerObj.nextLine();
        System.out.println("Input Manufacturer : ");
        scannerObj = new Scanner(System.in);
        String manufacturer = scannerObj.nextLine();
        System.out.println("Input Price : ");
        scannerObj = new Scanner(System.in);
        double price = Double.parseDouble(scannerObj.nextLine());

        Watch dto = new Watch(id, name, manufacturer, price);
        if (!checkDuplicatedId(dto.getId())) {
            System.out.println("Inserted successfully");
            listWatch.add(dto);
            dto.showDetail();
        } else {
            System.out.println("Something wrong");
        }
    }

    public boolean checkDuplicatedId(String id) {
        // Your code here
        for (int i = 0; i < listWatch.size(); i++) {
            String idChecked = listWatch.get(i).getId();
            if (idChecked.equals(id)) {
                return true;
            }
        }
        return false;
    }

    public void update() {
        // Print the object details after updating name/model and price

        System.out.println("Input Id to search : ");
        scannerObj = new Scanner(System.in);
        String id = scannerObj.nextLine();
        int index = findIndex(id);
        if (index != -1) {
            System.out.println("Input Name : ");
            scannerObj = new Scanner(System.in);
            String name = scannerObj.nextLine();
            System.out.println("Input Manufacturer : ");
            scannerObj = new Scanner(System.in);
            String manufacturer = scannerObj.nextLine();
            System.out.println("Input Price : ");
            scannerObj = new Scanner(System.in);
            double price = Double.parseDouble(scannerObj.nextLine());
            Watch dto = findWatchById(id);
            if (dto != null) {
                dto.setManufacturer(manufacturer);
                dto.setName(name);
                dto.setPrice(price);
                System.out.println("Updated successfully");
                dto.showDetail();
            } else {
                System.out.println("Something wrong");
            }
        } else {
            System.out.println("Watch with ID not found");
        }
    }

    public void search() {
        // Print the object details after searching
        System.out.println("Input Id to search : ");
        scannerObj = new Scanner(System.in);
        String id = scannerObj.nextLine();
        Watch getWatch = findWatchById(id);
        if (getWatch != null) {
            getWatch.showDetail();
        }
    }

    public void remove() {
        // Print the object details after removing
        System.out.println("Input Id to search : ");
        scannerObj = new Scanner(System.in);
        String id = scannerObj.nextLine();
        int index = findIndex(id);
        if (index != -1) {
            listWatch.remove(listWatch.get(index));
            printAll();
        }
    }

    public void sort() {
        // Print the object details after sorting
        String msg = String.format("SE1267|%-5s|%10s|%5s|%5s", "ID", "NAME", "MANUFACTURER", "PRICE");
        System.out.println(msg);
        Collections.sort(listWatch);
        printAll();
    }

    public int findIndex(String watchId) {
        for (int i = 0; i < listWatch.size(); i++) {
            String getId = listWatch.get(i).getId();
            if (getId.equals(watchId) ) {
                return i;
            }
        }
        return -1;
    }

    public Watch findWatchById(String watchId) {
        for (int i = 0; i < listWatch.size(); i++) {
            Watch getWatch = listWatch.get(i);
            if (getWatch.getId().equals(watchId)) {
                return getWatch;
            }
        }
        return null;
    }

    public void printAll() {
        for (int i = 0; i < listWatch.size(); i++) {
            Watch getWatch = listWatch.get(i);
            getWatch.showDetail();
        }
    }
}
