package com.thucnh.azuredevops.student;

public class StudentWork {

    // Student work in here

    public Integer computeQuestion1(Integer a, Integer b) {
        return a + b;
    }

    public Integer computeQuestion2(Integer a, Integer b) {
        return a + b;
    }

    public String computeQuestion3(Integer a, Integer b) {
        return a + b + "Testsf";
    }

    public String computeQuestion4(Integer a, Integer b) {
        return a + b + "Testfafs";
    }
}
