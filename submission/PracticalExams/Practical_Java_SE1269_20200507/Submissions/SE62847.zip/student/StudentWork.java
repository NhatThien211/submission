package com.practicalexam.student;

public class StudentWork {

    public Integer computeQuestion1(Integer a, Integer b) {
        return a + b;
    }

    public Integer computeQuestion2(Integer a, Integer b) {
        return a + b;
    }

    public String computeQuestion3(Integer a, Integer b) {
        return a + b + "Failed 1 cau";
    }

    public String computeQuestion4(Integer a, Integer b) {
        return a + b + "Test4";
    }
}
