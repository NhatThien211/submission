/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.tblUser;

import com.practicalexam.student.connection.DBUtilities;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.NamingException;

/**
 *
 * @author NhatBPM;
 */
public class TblUserDAO implements Serializable{
    private Connection con;
    private PreparedStatement pst;
    private ResultSet rs;
    
    private void closeConnection() throws SQLException{
        if (con != null) {
            con.close();
        }
        if (pst != null) {
            pst.close(); 
        }
        if (rs != null) {
            rs.close();
        }
    }
    
    public boolean checkLogin(String username, String password) throws SQLException, ClassNotFoundException, NamingException{
        try {
            con = DBUtilities.makeConnection();
            if (con != null) {
                String sql = "SELECT userId, password, fullName, boss "
                        + "FROM tbl_User "
                        + "Where userId = ? AND password = ? AND boss = ? ";
                pst = con.prepareStatement(sql);
                pst.setString(1, username);
                pst.setInt(2, Integer.parseInt(password));
                pst.setBoolean(3, true);
                rs = pst.executeQuery();
                if (rs.next()) {
                    return true;
                }
            }
        } finally {
            closeConnection();
        }
        return false;
    }
    
    public String getFullName(String username) throws ClassNotFoundException, NamingException, SQLException{
        try {
            con = DBUtilities.makeConnection();
            if (con != null) {
                String sql = "SELECT fullName "
                        + "FROM tbl_User"
                        + "WHERE userId = ?";
                pst = con.prepareStatement(sql);
                pst.setString(1, username);
                rs = pst.executeQuery();
                if (rs.next()) {
                    return rs.getString("fullName");
                }
            }
        } finally {
            closeConnection();
        }
        return null;
    }
    
}
