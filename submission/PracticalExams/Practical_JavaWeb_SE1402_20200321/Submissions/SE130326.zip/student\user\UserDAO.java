/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.user;

import com.practicalexam.student.connection.DBUtilities;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.NamingException;

/**
 *
 * @author YANO HUYNH
 */
public class UserDAO {
    static Connection cnn = null;
    static PreparedStatement preStm = null;
    static ResultSet rs = null;
    
    public static void closeConnection() throws SQLException {
        if (rs != null) {
            rs.close();
        } 
        if (preStm != null) {
            preStm.close();
        }
        if (cnn != null) {
            cnn.close();
        }
    }
    
    public static boolean checkLogin(String username, String password)
                    throws SQLException, NamingException, ClassNotFoundException {
        boolean check = false;
        try {
            cnn = DBUtilities.makeConnection();
            // Student Call function
            String sql = "Select userId "
                    + "From tbl_User "
                    + "Where userId = ? and password = ?";
            preStm = cnn.prepareStatement(sql);
            preStm.setString(1, username);
            preStm.setString(2, password);
            rs = preStm.executeQuery();
            if (rs.next()) {
                check = true;
            }
            // check = objectDAO.checkLogin(username, password);
            
            //
        } catch (SQLException e) {
            throw new SQLException();
        } catch (NamingException e) {
            throw new NamingException();
        } catch (ClassNotFoundException e) {
            throw new ClassNotFoundException();
        } finally {
            closeConnection();
        }
        return check;
    }
}
