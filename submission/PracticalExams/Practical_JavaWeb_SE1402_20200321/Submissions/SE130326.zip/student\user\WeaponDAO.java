/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.user;

import com.practicalexam.student.connection.DBUtilities;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.naming.NamingException;

/**
 *
 * @author YANO HUYNH
 */
public class WeaponDAO {
    static Connection cnn = null;
    static PreparedStatement preStm = null;
    static ResultSet rs = null;
    
    public static void closeConnection() throws SQLException {
        if (rs != null) {
            rs.close();
        } 
        if (preStm != null) {
            preStm.close();
        }
        if (cnn != null) {
            cnn.close();
        }
    }
    
    static List<WeaponDTO> listWeapon = null;
    
    public static List<WeaponDTO> getList() {
        return listWeapon;
    }
    
    public static int showAll() 
                    throws SQLException, NamingException, ClassNotFoundException {
        int result = -1;
        try {
            // Student call function
            cnn = DBUtilities.makeConnection();
            if (cnn != null) {
                String sql = "Select description, classification, defense, timeOfCreate, status "
                        + "From tbl_Weapon";
                preStm = cnn.prepareStatement(sql);
                rs = preStm.executeQuery();
                while (rs.next()) {
                    String description = rs.getString("description");
                    String classification = rs.getString("classification");
                    String defense = rs.getString("defense");
                    Date timeOfCreate = rs.getDate("timeOfCreate");
                    boolean status = rs.getBoolean("status");
                    WeaponDTO dto = new WeaponDTO(description, classification, defense, timeOfCreate, status);
                    if (listWeapon == null) {
                        listWeapon = new ArrayList<>();
                    }
                    listWeapon.add(dto);
                    result += 1;
                }
            }
            // result = objectDAO.searchLastname(lastname).size();
            
            //
        } catch (SQLException e) {
            throw new SQLException();
        } catch (NamingException e) {
            throw new NamingException();
        } catch (ClassNotFoundException e) {
            throw new ClassNotFoundException();
        } finally {
            closeConnection();
        }
        return result;
    }
}
