/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.user;

import java.sql.Date;

/**
 *
 * @author YANO HUYNH
 */
public class WeaponDTO {
    private String description;
    private String classification;
    private String defense;
    private Date timeOfCreate;
    private boolean status;

    public WeaponDTO() {
    }

    public WeaponDTO(String description, String classification, String defense, Date timeOfCreate, boolean status) {
        this.description = description;
        this.classification = classification;
        this.defense = defense;
        this.timeOfCreate = timeOfCreate;
        this.status = status;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the classification
     */
    public String getClassification() {
        return classification;
    }

    /**
     * @param classification the classification to set
     */
    public void setClassification(String classification) {
        this.classification = classification;
    }

    /**
     * @return the defense
     */
    public String getDefense() {
        return defense;
    }

    /**
     * @param defense the defense to set
     */
    public void setDefense(String defense) {
        this.defense = defense;
    }

    /**
     * @return the timeOfCreate
     */
    public Date getTimeOfCreate() {
        return timeOfCreate;
    }

    /**
     * @param timeOfCreate the timeOfCreate to set
     */
    public void setTimeOfCreate(Date timeOfCreate) {
        this.timeOfCreate = timeOfCreate;
    }

    /**
     * @return the status
     */
    public boolean isStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(boolean status) {
        this.status = status;
    }
    
}
