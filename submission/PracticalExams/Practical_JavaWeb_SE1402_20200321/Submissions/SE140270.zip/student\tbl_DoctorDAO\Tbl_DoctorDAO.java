/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.tbl_DoctorDAO;

import com.practicalexam.student.connection.DBUtilities;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.NamingException;

/**
 *
 * @author Le Ngoc Tan
 */
public class Tbl_DoctorDAO {

    public boolean checkLogin(String username, String password)
            throws ClassNotFoundException, NamingException, SQLException {
        Connection con = null;
        PreparedStatement pStm = null;
        ResultSet rs = null;
        try {
            con = DBUtilities.makeConnection();
            if (con != null) {
                String sql = "Select doctorId, password "
                        + "From tbl_Doctor "
                        + "Where doctorId = ? And password = ?";
                pStm = con.prepareStatement(sql);
                pStm.setString(1, username);
                pStm.setString(2, password);
                rs = pStm.executeQuery();
                if (rs.next()) {
                    return true;
                }
            }
        } finally {
            if (con != null) {
                con.close();
            }
            if (pStm != null) {
                pStm.close();
            }
            if (rs != null) {
                rs.close();
            }
        }
        return false;
    }

    public String getFullnameFromUsername(String username)
            throws ClassNotFoundException, NamingException, SQLException {
        Connection con = null;
        PreparedStatement pStm = null;
        ResultSet rs = null;
        try {
            con = DBUtilities.makeConnection();
            if (con != null) {
                String sql = "Select fullName "
                        + "From tbl_Doctor "
                        + "Where doctorId = ?";
                pStm = con.prepareStatement(sql);
                pStm.setString(1, username);
                rs = pStm.executeQuery();
                if (rs.next()) {
                    return rs.getString("fullName");
                }
            }
        } finally {
            if (con != null) {
                con.close();
            }
            if (pStm != null) {
                pStm.close();
            }
            if (rs != null) {
                rs.close();
            }
        }
        return null;
    }
}
