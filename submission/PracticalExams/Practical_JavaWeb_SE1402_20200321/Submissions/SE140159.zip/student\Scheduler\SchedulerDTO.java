/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.Scheduler;

import java.io.Serializable;
import java.sql.Date;

/**
 *
 * @author GP73
 */
public class SchedulerDTO implements Serializable {
    private int id;
    private Date shiftDate;
    private Date fromDate;
    private Date dateTime;
    private String description;
    private String doctorID;

    public SchedulerDTO(int id, Date shiftDate, Date fromDate, Date dateTime, String description, String doctorID) {
        this.id = id;
        this.shiftDate = shiftDate;
        this.fromDate = fromDate;
        this.dateTime = dateTime;
        this.description = description;
        this.doctorID = doctorID;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getShiftDate() {
        return shiftDate;
    }

    public void setShiftDate(Date shiftDate) {
        this.shiftDate = shiftDate;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getDateTime() {
        return dateTime;
    }

    public void setDateTime(Date dateTime) {
        this.dateTime = dateTime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(String doctorID) {
        this.doctorID = doctorID;
    }
}
