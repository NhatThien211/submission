/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.Scheduler;

import com.practicalexam.student.connection.DBUtilities;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.naming.NamingException;

/**
 *
 * @author GP73
 */
public class SchedulerDAO implements Serializable {
    private ArrayList<SchedulerDTO> schedulerList;
    
    public ArrayList<SchedulerDTO> getSchedulerList() {
        return schedulerList;
    }
    
    public boolean showAll() 
            throws NamingException, SQLException {
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        try {
            con = DBUtilities.makeConnection();
            if (con != null) {
                String sql = "Select id, shiftDate, fromDate, dateTime, description, doctorID "
                            + "From Scheduler";
                stm = con.prepareStatement(sql);
                rs = stm.executeQuery();
                while (rs.next()) {
                    int id = rs.getInt("id");
                    Date shiftDate = rs.getDate("shiftDate");
                    Date fromDate = rs.getDate("fromDate");
                    Date dateTime = rs.getDate("dateTime");
                    String description = rs.getString("description");
                    String doctorID = rs.getString("doctorID");
                    
                    SchedulerDTO dto = new SchedulerDTO(id, shiftDate, fromDate, dateTime, description, doctorID);
                    if (this.schedulerList == null) {
                        this.schedulerList = new ArrayList<>();
                    }
                    
                    this.schedulerList.add(dto);
                }
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
    }
        return false;
        
    }    
}
