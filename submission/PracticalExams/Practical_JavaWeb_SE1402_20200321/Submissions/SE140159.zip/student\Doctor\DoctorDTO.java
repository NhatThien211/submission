/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.Doctor;

import java.io.Serializable;
import java.sql.Date;

/**
 *
 * @author GP73
 */
public class DoctorDTO implements Serializable {
    
    
    
}
