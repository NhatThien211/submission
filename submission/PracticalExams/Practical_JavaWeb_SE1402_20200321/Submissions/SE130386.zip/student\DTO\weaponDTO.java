/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.DTO;

import java.io.Serializable;
import java.sql.Date;

/**
 *
 * @author Admin
 */
public class weaponDTO implements Serializable{
    private String amourld,description,classification,defense;
    private Date timeOfCreate;
    private boolean status;

    public weaponDTO(String amourld, String description, String classification, String defense, Date timeOfCreate, boolean status) {
        this.amourld = amourld;
        this.description = description;
        this.classification = classification;
        this.defense = defense;
        this.timeOfCreate = timeOfCreate;
        this.status = status;
    }

    public String getAmourld() {
        return amourld;
    }

    public void setAmourld(String amourld) {
        this.amourld = amourld;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public String getDefense() {
        return defense;
    }

    public void setDefense(String defense) {
        this.defense = defense;
    }

    public Date getTimeOfCreate() {
        return timeOfCreate;
    }

    public void setTimeOfCreate(Date timeOfCreate) {
        this.timeOfCreate = timeOfCreate;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
    
    
}
