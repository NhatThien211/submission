/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.DAO;

import com.practicalexam.student.connection.DBUtilities;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.NamingException;

/**
 *
 * @author Admin
 */
public class AccountDAO implements Serializable{
    Connection conn= null;
    PreparedStatement pre = null;
    ResultSet rs = null;
    
    public void closeConnection() throws NamingException, SQLException{
        try {
            if (conn != null) {
                conn.close();
            }
            if (pre != null) {
                pre.close();
            }
            if (rs != null) {
                rs.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public boolean checkLogin(String username, int password, boolean boss) throws NamingException,SQLException{
        Boolean bossRole = true;
        try {
            conn = DBUtilities.makeConnection();
            String sql = "Select userIdform tbl_User where userId=? and password=? and boss=?";
            pre = conn.prepareStatement(sql);
            pre.setString(1, username);
            pre.setInt(2, password);
            pre.setBoolean(3, true);
            rs = pre.executeQuery();
            if (rs.next()) {
                return true;
            }
        } finally{
            closeConnection();
        }
        return false;
    }
}
