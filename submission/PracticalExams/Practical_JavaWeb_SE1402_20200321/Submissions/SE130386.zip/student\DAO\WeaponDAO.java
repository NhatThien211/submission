/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.DAO;

import com.practicalexam.student.DTO.weaponDTO;
import com.practicalexam.student.connection.DBUtilities;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.naming.NamingException;

/**
 *
 * @author Admin
 */
public class WeaponDAO implements Serializable {

    Connection conn = null;
    PreparedStatement pre = null;
    ResultSet rs = null;

    public void closeConnection() throws NamingException, SQLException {
        try {
            if (conn != null) {
                conn.close();
            }
            if (pre != null) {
                pre.close();
            }
            if (rs != null) {
                rs.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private List<weaponDTO> list = null;

    public List<weaponDTO> searchWeapon(String weaponId) throws NamingException, SQLException {
        weaponDTO dto = null;
        list = new ArrayList<>();
        try {
            conn = DBUtilities.makeConnection();
            String sql = "select amourld,description,classification,defense,timeOfCreate,status from tbl_Weapon where amourld=?";
            pre = conn.prepareStatement(sql);
            pre.setString(1, "%" + weaponId + "%");
            rs = pre.executeQuery();
            while (rs.next()) {            
                String weaID = rs.getString("amourld");
                String des = rs.getString("description");
                String cla = rs.getString("classification");
                String def = rs.getString("defense");
                Date date = rs.getDate("timeOfCreate");
                boolean status = rs.getBoolean("status");
                dto = new weaponDTO(weaID, des, cla, def, date, status);
                list.add(dto);
                
            }

        } finally {
            closeConnection();
        }
        return list;
    }
        public List<weaponDTO> showAll() throws NamingException, SQLException {
        weaponDTO dto = null;
        list = new ArrayList<>();
        try {
            conn = DBUtilities.makeConnection();
            String sql = "select amourld,description,classification,defense,timeOfCreate,status from tbl_Weapon";
            pre = conn.prepareStatement(sql);
            
            rs = pre.executeQuery();
            while (rs.next()) {            
                String weaID = rs.getString("amourld");
                String des = rs.getString("description");
                String cla = rs.getString("classification");
                String def = rs.getString("defense");
                Date date = rs.getDate("timeOfCreate");
                boolean status = rs.getBoolean("status");
                dto = new weaponDTO(weaID, des, cla, def, date, status);
                list.add(dto);
                
            }

        } finally {
            closeConnection();
        }
        return list;
    }
}
