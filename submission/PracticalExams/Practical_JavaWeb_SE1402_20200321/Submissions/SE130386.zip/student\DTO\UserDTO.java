/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.DTO;

import java.io.Serializable;

/**
 *
 * @author Admin
 */
public class UserDTO implements Serializable{
    private String username,fullname;
    private int password;
    private boolean boss;

    public UserDTO(String username, String fullname, int password, boolean boss) {
        this.username = username;
        this.fullname = fullname;
        this.password = password;
        this.boss = boss;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public int getPassword() {
        return password;
    }

    public void setPassword(int password) {
        this.password = password;
    }

    public boolean isBoss() {
        return boss;
    }

    public void setBoss(boolean boss) {
        this.boss = boss;
    }
    
    
}
