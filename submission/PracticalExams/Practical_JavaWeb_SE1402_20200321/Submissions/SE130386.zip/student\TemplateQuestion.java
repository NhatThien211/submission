package com.practicalexam.student;

import com.practicalexam.student.DAO.AccountDAO;
import com.practicalexam.student.DAO.WeaponDAO;
import java.io.Serializable;

public class TemplateQuestion implements Serializable {
    
    private static AccountDAO accountDao = new AccountDAO();
    private static WeaponDAO weaponDao = new WeaponDAO();

    public static boolean checkLogin(String username, String password) {
        boolean check = false;
        try {
            // Student Call function
            check = accountDao.checkLogin(username, Integer.parseInt(password), true);
            //
        } catch (Exception e) {
            e.printStackTrace();
        }
        return check;
    }

    public static boolean delete(String armorId) {
        boolean check = false;
        try {
            // Student call function

            //
        } catch (Exception e) {
            e.printStackTrace();
        }
        return check;
    }

    public static int showAll() {
        int result = -1;
        try {
            // Student call function
            result = weaponDao.showAll().size();
            //
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

}
