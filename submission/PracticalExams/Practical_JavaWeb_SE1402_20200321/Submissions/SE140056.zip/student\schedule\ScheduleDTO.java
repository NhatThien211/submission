/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.schedule;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 *
 * @author Tam
 */
public class ScheduleDTO implements Serializable {
    private int id;
    private Timestamp shiftDate;
    private Timestamp fromDate;
    private Timestamp dateTime;
    private String description;
    private String doctorId;

    public ScheduleDTO() {
    }

    public ScheduleDTO(int id, Timestamp shiftDate, Timestamp fromDate, Timestamp dateTime, String description, String doctorId) {
        this.id = id;
        this.shiftDate = shiftDate;
        this.fromDate = fromDate;
        this.dateTime = dateTime;
        this.description = description;
        this.doctorId = doctorId;
    }

    public Timestamp getDateTime() {
        return dateTime;
    }

    public void setDateTime(Timestamp dateTime) {
        this.dateTime = dateTime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public Timestamp getFromDate() {
        return fromDate;
    }

    public void setFromDate(Timestamp fromDate) {
        this.fromDate = fromDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Timestamp getShiftDate() {
        return shiftDate;
    }

    public void setShiftDate(Timestamp shiftDate) {
        this.shiftDate = shiftDate;
    }
    
}
