package com.practicalexam.student;

import com.practicalexam.student.connection.DBUtilities;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.naming.NamingException;

public class TemplateQuestion implements Serializable {

    public static boolean checkLogin(String username, String password)
            throws NamingException, SQLException, ClassNotFoundException {
        boolean check = false;
        Connection c = null;
        PreparedStatement ps = null;
        ResultSet result = null;
        try {
            // Student Call function
            c = DBUtilities.makeConnection();
            String order = "SELECT leader FROM tbl_Doctor WHERE doctorId = ? AND password = ?";
            ps = c.prepareStatement(order);

            ps.setString(1, username);
            ps.setString(2, password);

            result = ps.executeQuery();
            while (result.next()) {
                boolean role = result.getBoolean("leader");
                if (role == true) {
                    check = true;
                }
            }
            // check = objectDAO.checkLogin(username, password);

            //
        } finally {
            if (c != null) {
                c.close();
            }
            if (ps != null) {
                ps.close();
            }
        }
        return check;
    }

    public static int searchByLastname(String lastname) {

        int result = -1;
        try {
            // Student call function

            // result = objectDAO.searchLastname(lastname).size();
            //
        } catch (Exception e) {
        }
        return result;
    }

   
    public static int searchDoctorSchedule(Date from, Date to, String doctorId) {
        int result = -1;
        try {
            // Student call function
            
            // result = objectDAO.searchLastname(lastname).size();
            
            //
        } catch (Exception e) {
        }
        return result;
    }

    public static int getAllDoctorSchedule() {
        int result = -1;
        try {
            // Student call function

            // result = objectDAO.searchLastname(lastname).size();

            //
        } catch (Exception e) {
        }
        return result;
    }

}
