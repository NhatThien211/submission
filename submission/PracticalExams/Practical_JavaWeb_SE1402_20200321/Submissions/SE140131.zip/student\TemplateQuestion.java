package com.practicalexam.student;

import com.practicalexam.student.tbl_Doctor.Tbl_DoctorDAO;
import java.io.Serializable;
import java.util.Date;

public class TemplateQuestion implements Serializable {

    public static boolean checkLogin(String username, String password) {
        boolean check = false;
        try {
            Tbl_DoctorDAO dao = new Tbl_DoctorDAO();
            
             check = dao.checkLogin(username, password);
            
            //
        } catch (Exception e) {
        }
        return check;
    }

    public static int searchDoctorSchedule(Date from, Date to, String doctorId) {
        int result = -1;
        try {
            // Student call function
            
            // result = objectDAO.searchLastname(lastname).size();
            
            //
        } catch (Exception e) {
        }
        return result;
    }

    public static int getAllDoctorSchedule() {
        int result = -1;
        try {
            // Student call function

            // result = objectDAO.searchLastname(lastname).size();

            //
        } catch (Exception e) {
        }
        return result;
    }

}
