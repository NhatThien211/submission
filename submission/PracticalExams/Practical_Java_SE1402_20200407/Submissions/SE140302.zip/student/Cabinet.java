package com.practicalexam.student;

import com.practicalexam.student.data.data;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;


/**
 *
 * @author FPT University - HCMC Java OOP Practical Exam Template
 */
public class Cabinet {

    //StartList - do not remove this comment!!!
    // Declare ArrayList or Array here
    private ArrayList<data> datalist = new ArrayList();
    //EndList - do not remove this comment!!!
    private Scanner scannerObj = new Scanner(System.in);

    public void add() {
        // Print the object details after adding
        String code, model;
        int size;
        double price;
        boolean pos;
       {
            //code = MyToys.getCode("Input a shoe code(SXXXXX): ", "The format of code is SXXXXX(X stands for a digit)", "^[S|s]\\d{5}$");
            System.out.println("Input code : ");
            code = scannerObj.nextLine();
            pos = checkDuplicatedId(code);
            if (pos == true) {
                System.out.println("The shoe id already exists." + "PLEASE! Input another one");
            }
        } 

        // model = MyToys.getString("Input model name: ", "The model name is required!");
        System.out.println("Input Model : ");
        model = scannerObj.nextLine();
        //size = MyToys.getAnInteger("Input shoe size: ", "Please input shoe size!");
        System.out.println("Input Size : ");
        size = Integer.parseInt(scannerObj.nextLine());
        //price = MyToys.getADouble("Input shoe price: ", "Please input shoe price!");
        System.out.println("Input Price : ");
        price = Double.parseDouble(scannerObj.nextLine());
        data dto = new data(code, model, size, price); //Added
        datalist.add(dto);
        System.out.println("A new shoe profile is added sucessfully");
        dto.showProfile(); //Added
    }

    public boolean checkDuplicatedId(String shoeCode) {
        // Your code here

        //tìm kiếm: thuật toán trâu bò, rà, quét hết mảng
        //so khớp id của Pet thứ i trong mảng coi có bằng id đưa vào hem
        int pos;
        if (datalist.isEmpty()) //ko có con Pet nào, kết thúc cuộc chơi ngay
        {
            return false; //ko tìm gì cả
        }        //quét hết list, coi có trùng id nào ko, thì trả về vị trí
        for (int i = 0; i < datalist.size(); i++) {
            if (datalist.get(i).getCode().equalsIgnoreCase(shoeCode)) {
                return true;
            }
        }
        //đi hết cả for mà hok thấy, thì return -1 - not found
        return false;
    }

    public void update() {
        // Print the object details after updating name/model and price
        String code;
        String model;
        double price;
        data x;  //con trỏ trỏ tạm thời đến Pet tìm thấy
        System.out.println("Input code : ");
        code = scannerObj.nextLine();
        x = searchShoeObjectByCode(code);
        System.out.println("------------------------------------");
        if (x == null) {
            System.out.println("Not found!!!");
        } else {
            System.out.println("Here is the Pet before updating");
            x.showProfile();
            System.out.println("You are required to input a new name");
            System.out.println("Input Model : ");
            model = scannerObj.nextLine();
            x.setModel(model);
            System.out.println("Input Price : ");
            price = Double.parseDouble(scannerObj.nextLine());
            x.setPrice(price);
            System.out.println("The pet info is updated successfully!");
            System.out.println("Here is the Shoe after updating: ");
            x.showProfile();
        }
    }

    public void search() {
        // Print the object details after searching
        String code;
        data x;  //con trỏ trỏ tạm thời đến Pet tìm thấy
        System.out.println("Input code : ");
        code = scannerObj.nextLine();
        x = searchShoeObjectByCode(code);
        System.out.println("------------------------------------");
        if (x == null) {
            System.out.println("Not found!!!");
        } else {
            System.out.println("Here is the Shoe"
                    + "that you want to search");
            x.showProfile();
        }
    }

    public void remove() {
        /*  // Print the list after removing
        String code;
        int pos;
        //vị trí tìm thấy pe
        code = MyToys.getString("Input pet id: ", "Pet id is required!");

        if(datalist.isEmpty())
            System.out.println("Shoe is not exists");
        else{
             for (int i = 0; i < datalist.size(); i++) {
            if(datalist.get(i).getCode().equalsIgnoreCase(code))
                 pos=i;
             }
            datalist.remove(pos);
            System.out.println("The selected shoe is removed successfully");

        }
         */
    }

    public void sort() {
        // Print the object details after sorting
        if (datalist.isEmpty()) {
            System.out.println("It is empty. Nothing to print!");
            return;
        }
        Comparator nameBalance = new Comparator<data>() {
            @Override
            public int compare(data o1, data o2) {
                return o1.getModel().compareToIgnoreCase(o2.getModel());
            }
        };
        Collections.sort(datalist, nameBalance);
        System.out.println("------------------------------------");
        System.out.println("Here is the shoe list");
        String header = String.format("|SE140302|%-15s|%4s|%4s|%4s|", "code", "model", "size", "price");
        System.out.println(header);
        for (int i = 0; i < datalist.size(); i++) {
            datalist.get(i).showProfile();
        }
    }

    public data searchShoeObjectByCode(String shoeCode) {
        if (datalist.isEmpty()) //ko có con nào, thì return null
        {
            return null;
        }
        for (int i = 0; i < datalist.size(); i++) {
            if (datalist.get(i).getCode().equalsIgnoreCase(shoeCode)) {
                return datalist.get(i);
            }
        }
        //̣đi hết cả for mà hok thấy, đích thị là return null
        return null;
    }

}
