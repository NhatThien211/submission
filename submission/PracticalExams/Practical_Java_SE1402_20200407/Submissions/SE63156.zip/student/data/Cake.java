package com.practicalexam.student.data;

public class Cake {
}
