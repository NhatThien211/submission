package com.practicalexam.student.data;

public class Watch implements Comparable<Watch> {

    private String id;
    private String name;
    private String manufacturer;
    private double price;

    public Watch() {
    }

    public Watch(String id, String name, String manufacturer, double price) {
        this.id = id;
        this.name = name;
        this.manufacturer = manufacturer;
        this.price = price;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public int compareTo(Watch o) {
        if (name.compareTo(o.name) == 0) {
            return 0;
        } else if (name.compareTo(o.name) > 0) {
            return 1;
        } else {
            return -1;
        }
    }

    public void showDetail() {
        String msg = String.format("SE1267|%-5s|%10s|%5s|%5f", id, name, manufacturer, price);
        System.out.println(msg);
    }

}
