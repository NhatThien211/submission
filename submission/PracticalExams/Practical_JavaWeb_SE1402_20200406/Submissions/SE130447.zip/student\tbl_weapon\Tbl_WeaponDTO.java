/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.tbl_weapon;

import java.sql.Timestamp;

/**
 *
 * @author nhocc
 */
public class Tbl_WeaponDTO {

    private String amourId;
    private String description;
    private String classification;
    private String defense;
    private Timestamp timeOfCreate;
    private boolean status;

    public Tbl_WeaponDTO() {
    }

    public Tbl_WeaponDTO(String amourId, String description, String classification, String defense, Timestamp timeOfCreate, boolean status) {
        this.amourId = amourId;
        this.description = description;
        this.classification = classification;
        this.defense = defense;
        this.timeOfCreate = timeOfCreate;
        this.status = status;
    }

    public String getAmourId() {
        return amourId;
    }

    public void setAmourId(String amourId) {
        this.amourId = amourId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public String getDefense() {
        return defense;
    }

    public void setDefense(String defense) {
        this.defense = defense;
    }

    public Timestamp getTimeOfCreate() {
        return timeOfCreate;
    }

    public void setTimeOfCreate(Timestamp timeOfCreate) {
        this.timeOfCreate = timeOfCreate;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

}
