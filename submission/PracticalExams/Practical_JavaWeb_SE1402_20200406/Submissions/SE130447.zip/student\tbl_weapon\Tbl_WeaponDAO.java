/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.tbl_weapon;

import com.practicalexam.student.connection.DBUtilities;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import javax.naming.NamingException;

/**
 *
 * @author nhocc
 */
public class Tbl_WeaponDAO {

    private List<Tbl_WeaponDTO> listWeapon;

    public List<Tbl_WeaponDTO> getListWeapon() {
        return listWeapon;
    }

    public int showAll() throws NamingException, SQLException, ClassNotFoundException {
        int numOfRow = 0;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = DBUtilities.makeConnection();
            if (con != null) {
                String sql = "SELECT amourId, description, classification, defense, timeOfCreate, status "
                        + "FROM tbl_Weapon";
                ps = con.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {
                    String amourId = rs.getString("amourId");
                    String description = rs.getString("description");
                    String classification = rs.getString("classification");
                    String defense = rs.getString("defense");
                    Timestamp timeOfCreate = rs.getTimestamp("timeOfCreate");
                    boolean status = rs.getBoolean("status");
                    Tbl_WeaponDTO dto = new Tbl_WeaponDTO(amourId, description, classification, defense, timeOfCreate, status);
                    if (listWeapon == null) {
                        listWeapon = new ArrayList<>();
                    }
                    listWeapon.add(dto);
                    numOfRow++;
                }
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return numOfRow;
    }
}
