package com.practicalexam.student;

import com.practicalexam.student.tbl_user.Tbl_UserDAO;
import com.practicalexam.student.tbl_weapon.Tbl_WeaponDAO;
import java.io.Serializable;

public class TemplateQuestion implements Serializable {

    private static Tbl_UserDAO userDao = new Tbl_UserDAO();
    private static Tbl_WeaponDAO weaponDao = new Tbl_WeaponDAO();

    public static boolean checkLogin(String username, String password) {
        boolean check = false;
        try {
            // Student Call function
            check = userDao.checkLogin(username, password);
            //
        } catch (Exception e) {
            e.printStackTrace();
        }
        return check;
    }

    public static boolean delete(String armorId) {
        boolean check = false;
        try {
            // Student call function

            //
        } catch (Exception e) {
            e.printStackTrace();
        }
        return check;
    }

    public static int showAll() {
        int result = -1;
        try {
            // Student call function
            result = weaponDao.showAll();
            //
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

}
