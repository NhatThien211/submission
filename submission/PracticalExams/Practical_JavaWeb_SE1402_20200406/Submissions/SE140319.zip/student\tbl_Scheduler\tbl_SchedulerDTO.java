/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.tbl_Scheduler;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author HOME
 */
public class tbl_SchedulerDTO implements Serializable{
    private int id;
    private Date shift;
    private Date from;
    private Date to;
    private String des;
    private String docId;

    public tbl_SchedulerDTO() {
    }

    public tbl_SchedulerDTO(int id, Date shift, Date from, Date time, String des, String docId) {
        this.id = id;
        this.shift = shift;
        this.from = from;
        this.to = time;
        this.des = des;
        this.docId = docId;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the shift
     */
    public Date getShift() {
        return shift;
    }

    /**
     * @param shift the shift to set
     */
    public void setShift(Date shift) {
        this.shift = shift;
    }

    /**
     * @return the from
     */
    public Date getFrom() {
        return from;
    }

    /**
     * @param from the from to set
     */
    public void setFrom(Date from) {
        this.from = from;
    }

    /**
     * @return the time
     */
    public Date getTo() {
        return to;
    }

    /**
     * @param time the time to set
     */
    public void setTo(Date time) {
        this.to = time;
    }

    /**
     * @return the des
     */
    public String getDes() {
        return des;
    }

    /**
     * @param des the des to set
     */
    public void setDes(String des) {
        this.des = des;
    }

    /**
     * @return the docId
     */
    public String getDocId() {
        return docId;
    }

    /**
     * @param docId the docId to set
     */
    public void setDocId(String docId) {
        this.docId = docId;
    }
    
}
