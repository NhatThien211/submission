package com.practicalexam.student;


import com.practicalexam.student.tbl_Doctor.tbl_DoctorDAO;
import com.practicalexam.student.tbl_Scheduler.tbl_SchedulerDAO;
import java.io.Serializable;
import java.util.Date;

public class TemplateQuestion implements Serializable {

    public static boolean checkLogin(String username, String password) {
        boolean check = false;
        try {
            // Student Call function
            tbl_DoctorDAO dao = new tbl_DoctorDAO();
            check = dao.checkLogin(username, password);
            //
        } catch (Exception e) {
        }
        return check;
    }

    public static int searchDoctorSchedule(Date from, Date to, String doctorId) {
        int result = -1;
        try {
            // Student call function
            tbl_SchedulerDAO dao = new tbl_SchedulerDAO();
            result = dao.search(from, to).size();
            //
        } catch (Exception e) {
        }
        return result;
    }

    public static int getAllDoctorSchedule() {
        int result = -1;
        try {
            // Student call function
          
            //
        } catch (Exception e) {
        }
        return result;
    }

}
