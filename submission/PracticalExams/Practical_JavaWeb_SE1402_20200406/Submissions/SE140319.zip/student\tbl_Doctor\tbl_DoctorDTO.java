/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.tbl_Doctor;

import java.io.Serializable;

/**
 *
 * @author HOME
 */
public class tbl_DoctorDTO implements Serializable{
    private String id;
    private String name;
    private String spec;
    private String phone;
    private String addr;
    private String pass;
    private boolean leader;

    public tbl_DoctorDTO() {
    }

    public tbl_DoctorDTO(String id, String name, String spec, String phone, String addr, String pass, boolean leader) {
        this.id = id;
        this.name = name;
        this.spec = spec;
        this.phone = phone;
        this.addr = addr;
        this.pass = pass;
        this.leader = leader;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the spec
     */
    public String getSpec() {
        return spec;
    }

    /**
     * @param spec the spec to set
     */
    public void setSpec(String spec) {
        this.spec = spec;
    }

    /**
     * @return the phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * @return the addr
     */
    public String getAddr() {
        return addr;
    }

    /**
     * @param addr the addr to set
     */
    public void setAddr(String addr) {
        this.addr = addr;
    }

    /**
     * @return the pass
     */
    public String getPass() {
        return pass;
    }

    /**
     * @param pass the pass to set
     */
    public void setPass(String pass) {
        this.pass = pass;
    }

    /**
     * @return the leader
     */
    public boolean isLeader() {
        return leader;
    }

    /**
     * @param leader the leader to set
     */
    public void setLeader(boolean leader) {
        this.leader = leader;
    }
    
    
}
