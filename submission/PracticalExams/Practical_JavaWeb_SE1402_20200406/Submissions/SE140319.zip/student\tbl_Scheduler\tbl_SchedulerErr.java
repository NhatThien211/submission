/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.tbl_Scheduler;

import java.io.Serializable;

/**
 *
 * @author HOME
 */
public class tbl_SchedulerErr implements Serializable{
    private String wrongFromFormat;
    private String wrongToFormat;

    public tbl_SchedulerErr() {
    }

    /**
     * @return the wrongFromFormat
     */
    public String getWrongFromFormat() {
        return wrongFromFormat;
    }

    /**
     * @param wrongFromFormat the wrongFromFormat to set
     */
    public void setWrongFromFormat(String wrongFromFormat) {
        this.wrongFromFormat = wrongFromFormat;
    }

    /**
     * @return the wrongToFormat
     */
    public String getWrongToFormat() {
        return wrongToFormat;
    }

    /**
     * @param wrongToFormat the wrongToFormat to set
     */
    public void setWrongToFormat(String wrongToFormat) {
        this.wrongToFormat = wrongToFormat;
    }
    
}
