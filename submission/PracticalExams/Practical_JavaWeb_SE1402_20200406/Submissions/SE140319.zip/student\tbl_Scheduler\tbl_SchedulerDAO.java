/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.tbl_Scheduler;

import com.practicalexam.student.connection.DBUtilities;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.naming.NamingException;

/**
 *
 * @author HOME
 */


public class tbl_SchedulerDAO implements Serializable{
    private List<tbl_SchedulerDTO> list;
    
    public List search(Date from,Date to) throws SQLException, ClassNotFoundException, NamingException {
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        try {
            con = DBUtilities.makeConnection();
            if (con != null) {
                String sql = "SELECT shiftDate , fromTime, dateTime, description "
                        + "FROM tbl_Scheduler "
                        + "WHERE fromTime = ? , dateTime = ?";
                stm = con.prepareStatement(sql);
                rs = stm.executeQuery();
                while (rs.next()) {
                    tbl_SchedulerDTO dto = new tbl_SchedulerDTO();
                    if (list == null) {
                        list = new ArrayList<>();
                    }
                    dto.setShift(to);
                    dto.setFrom(from);
                    dto.setTo(to);
                    dto.setDes(sql);
                    list.add(dto);
                }
                return list;
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return null;
    }
}
