/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.tblDoctor;

import com.practicalexam.student.connection.DBUtilities;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.NamingException;

/**
 *
 * @author Shirou
 */
public class tblDoctor_DAO implements Serializable{
    public boolean checkLogin(String username, String password) throws ClassNotFoundException, NamingException, SQLException {
        Connection con = null;
        PreparedStatement pStm = null;
        ResultSet rs = null; 
        try {
            con = DBUtilities.makeConnection();
            if(con!= null) {
                String sql = "Select doctorID "
                        + "From tbl_Doctor "
                        + "where doctorID = ? and password = ? ";
                pStm = con.prepareStatement(sql);
                pStm.setString(1, username);
                pStm.setString(2, password);
                rs = pStm.executeQuery();
                if(rs.next()) {
                    return true;
                }
            }
        } finally  {
            if (rs != null) {
                rs.close();
            }
            if (pStm != null) {
                pStm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return false;
    }
}
