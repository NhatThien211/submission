/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.user;

import com.practicalexam.student.connection.DBUtilities;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Microsoft Windows
 */
public class UserDAO  implements Serializable{
    public boolean checkLogin(String userid , String password) throws SQLException{
        Connection conn = null ;
        PreparedStatement preStm = null ;
        ResultSet rs = null;
        
        try {
            conn = DBUtilities.makeConnection();
            if(conn != null){
                String sql = "Select userId from tbl_User where userId = ? and password = ? and boss = ? ";
                preStm = conn.prepareStatement(sql);
                preStm.setString(1, userid);
                preStm.setString(2, password);
                preStm.setBoolean(3, true);
                rs = preStm.executeQuery();
                if(rs.next()){
                   return true;
                }
                        
            }
        }catch(Exception ex ){
            ex.printStackTrace();
        }finally{
            if(rs!=null){
                rs.close();
            }
            if(preStm!=null){
                preStm.close();
            }
            if(conn!=null){
                conn.close();
            }
        }
        
        
        return false ;
    }
}
