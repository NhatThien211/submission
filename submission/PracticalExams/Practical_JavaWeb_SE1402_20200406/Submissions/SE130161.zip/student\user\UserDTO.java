/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.user;

import java.io.Serializable;

/**
 *
 * @author Microsoft Windows
 */
public class UserDTO  implements Serializable{
    private String userid ,passowrd,fullname;
    private boolean isBoss ;

    public UserDTO(String userid, String passowrd, String fullname, boolean isBoss) {
        this.userid = userid;
        this.passowrd = passowrd;
        this.fullname = fullname;
        this.isBoss = isBoss;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getPassowrd() {
        return passowrd;
    }

    public void setPassowrd(String passowrd) {
        this.passowrd = passowrd;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public boolean isIsBoss() {
        return isBoss;
    }

    public void setIsBoss(boolean isBoss) {
        this.isBoss = isBoss;
    }
    
    
}
