/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.registration;

import com.practicalexam.student.connection.DBUtilities;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;

/**
 *
 * @author USER
 */
public class TblUserDAO implements Serializable{
    private Connection conn;
    private PreparedStatement preStm;
    private ResultSet rs;

    public TblUserDAO() {
    }
    
    public void closeConnection() throws SQLException{
        if(rs != null){
            rs.close();
        }
        if(preStm != null){
            preStm.close();
        }
        if(conn != null){
            conn.close();
        }
    }
    private String fullname;

    public String getFullname() {
        return fullname;
    }
    
    public boolean checkLogin(String username, String password) throws SQLException, NamingException, ClassNotFoundException{
        try{
            String sql = "Select fullname From tbl_User Where userId = ? and password = ? and boss = ?";
            conn = DBUtilities.makeConnection();
            preStm = conn.prepareStatement(sql);
            preStm.setString(1, username);
            preStm.setString(2, password);
            preStm.setBoolean(3, true);
            rs = preStm.executeQuery();
            if(rs.next()){
                fullname = rs.getString("fullname");
                return true;
            }
        
        } finally{
            closeConnection();
        }
        return false;
        
    }
    
}
