/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.registration;

import java.io.Serializable;

/**
 *
 * @author USER
 */
public class TblUserDTO implements Serializable{
    private String userId, fullname;
    private int password;
    private boolean boss;

    public TblUserDTO() {
    }

    public TblUserDTO(String userId, String fullname, int password, boolean boss) {
        this.userId = userId;
        this.fullname = fullname;
        this.password = password;
        this.boss = boss;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public int getPassword() {
        return password;
    }

    public void setPassword(int password) {
        this.password = password;
    }

    public boolean isBoss() {
        return boss;
    }

    public void setBoss(boolean boss) {
        this.boss = boss;
    }
    
    
    
}
