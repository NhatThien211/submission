/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.registration;

import com.practicalexam.student.connection.DBUtilities;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.NamingException;

/**
 *
 * @author USER
 */
public class TblWeaponDAO implements Serializable{
    private Connection conn;
    private PreparedStatement preStm;
    private ResultSet rs;

    public TblWeaponDAO() {
    }
    
    public void closeConnection() throws SQLException{
        if(rs != null){
            rs.close();
        }
        if(preStm != null){
            preStm.close();
        }
        if(conn != null){
            conn.close();
        }
    }
    
    public int showAll() throws SQLException, NamingException, ClassNotFoundException{
        int row = 0;
        try{
            String sql = "Select amourId, description, classification, timeOfCreate FROM tbl_Weapon";
            conn = DBUtilities.makeConnection();
            preStm = conn.prepareStatement(sql);
            rs = preStm.executeQuery();
            while(rs.next()){
                
            }
        } finally{
            closeConnection();
        }
        return row;
    }
    
}
