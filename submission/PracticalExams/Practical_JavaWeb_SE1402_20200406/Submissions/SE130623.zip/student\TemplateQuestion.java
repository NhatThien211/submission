package com.practicalexam.student;

import com.practicalexam.student.Registration.RegistrationDAO;
import java.io.Serializable;

public class TemplateQuestion implements Serializable {

    private static RegistrationDAO dao = new RegistrationDAO();

    public static boolean checkLogin(String username, String password) {
        boolean check = false;
        try {
            // Student Call function
            check = dao.checkLogin(username, password);
            //
        } catch (Exception e) {
            e.printStackTrace();
        }
        return check;
    }

    public static boolean delete(String armorId) {
        boolean check = false;
        try {
            // Student call function

            //
        } catch (Exception e) {
            e.printStackTrace();
        }
        return check;
    }

    public static int showAll() {
        int result = -1;
        try {
            // Student call function

            //
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

}
