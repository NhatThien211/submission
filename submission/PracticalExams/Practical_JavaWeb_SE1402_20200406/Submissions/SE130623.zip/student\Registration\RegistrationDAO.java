/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.Registration;

import com.practicalexam.student.connection.DBUtilities;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.NamingException;

/**
 *
 * @author donglong
 */
public class RegistrationDAO implements Serializable{
    private Connection con;
    private PreparedStatement stm;
    private ResultSet rs;
    
    public void closeConnect() throws SQLException,NamingException{
        if(rs != null){
            rs.close();
        }
        if(stm != null){
            stm.close();
        }
        if(con != null){
            con.close();
        }
    }
    public boolean checkLogin(String username ,String password) throws SQLException,NamingException{
        try {
            con = DBUtilities.makeConnection();
            if(con != null){
                String sql ="select fullName from tbl_User "
                        + "where userId = ? and password = ? and boss ='True' ";
                stm = con.prepareStatement(sql);
                stm.setString(1, username);
                stm.setString(2, password);
                rs = stm.executeQuery();
                if(rs.next()){
                    return true;
                }
            }
        } finally {
            closeConnect();
        }
        return false;
    }
    
}
