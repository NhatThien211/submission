/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.chinhmt.doctor;

import com.practicalexam.student.connection.DBUtilities;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.NamingException;

/**
 *
 * @author Chinh
 */
public class DoctorDAO {
    public boolean checkLogin(String doctorId, String password) throws SQLException, NamingException, ClassNotFoundException{
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        try {
            con = DBUtilities.makeConnection();
            if (con != null) {
                String sql = "Select leader from tbl_Doctor where doctorId = ? and password = ?";
                stm = con.prepareStatement(sql);
                stm.setString(1, doctorId);
                stm.setString(2, password);
                rs = stm.executeQuery();
                if (rs.next()) {
                    if (rs.getBoolean("leader")) {
                        return true;
                    }
                }
            }
        } finally{
            if (rs != null) {
                rs.close();
            } if (stm != null) {
                stm.close();
            } if (con != null) {
                con.close();
            }
        }
        return false;
    }
}
