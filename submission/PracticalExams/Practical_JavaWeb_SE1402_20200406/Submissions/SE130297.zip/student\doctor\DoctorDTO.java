/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.doctor;

import java.io.Serializable;

/**
 *
 * @author ASUS
 */
public class DoctorDTO implements Serializable{
    private String doctorId;
    private String fullName;
    private String speciazation;
    private String phoneNumber;
    private String address;
    private String password;
    private boolean leader;

    public DoctorDTO() {
    }

    public DoctorDTO(String doctorId, String fullName, String speciazation, String phoneNumber, String address, String password, boolean leader) {
        this.doctorId = doctorId;
        this.fullName = fullName;
        this.speciazation = speciazation;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.password = password;
        this.leader = leader;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getSpeciazation() {
        return speciazation;
    }

    public void setSpeciazation(String speciazation) {
        this.speciazation = speciazation;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isLeader() {
        return leader;
    }

    public void setLeader(boolean leader) {
        this.leader = leader;
    }
    
    
}
