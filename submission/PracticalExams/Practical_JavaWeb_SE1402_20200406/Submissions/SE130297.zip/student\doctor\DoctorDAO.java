/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.doctor;

import com.practicalexam.student.connection.DBUtilities;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.NamingException;

/**
 *
 * @author ASUS
 */
public class DoctorDAO implements Serializable {
    public static boolean checkLogin(String username, String password) throws ClassNotFoundException, NamingException, SQLException{
         Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean check = false;
        try {
            // Student Call function
            con = DBUtilities.makeConnection();
            if(con != null){
                String sql = "SELECT doctorId" +
                        "FROM tbl_Doctor" +
                        "WHERE username = ? AND password = ? AND leader = ? ";
                ps = con.prepareStatement(sql);
                ps.setString(1, username);
                ps.setString(2, password);
                ps.setBoolean(3, true);
                rs = ps.executeQuery();
                if(rs.next()){
                    return true;
                }
            }
            
        }finally{
            if(rs != null){
                rs.close();
            }if(ps != null){
                rs.close();
            }if(con != null){
                con.close();
            }
        } 
        
        return check;
    }
}
