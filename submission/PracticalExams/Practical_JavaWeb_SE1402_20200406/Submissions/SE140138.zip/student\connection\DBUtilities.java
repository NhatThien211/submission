/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.connection;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.DataSource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 * @author Kieu Trong Khanh
 */
public class DBUtilities implements Serializable {

    public static Connection makeConnection()
            throws NamingException, SQLException {
        Connection con = null;
        
        // Students add code to make connection here
        Context context = new InitialContext();
        Context tomcatTx = (Context) context.lookup("java.comp/env");
        DataSource ds = (DataSource) tomcatTx.lookup("SE140138DS");
        
        con = ds.getConnection();
        
        
        return con;
    }

}
