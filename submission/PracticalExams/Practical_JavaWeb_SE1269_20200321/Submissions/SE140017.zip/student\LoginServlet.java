/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author tannt
 */
public class LoginServlet extends HttpServlet{
    private final String INVALID_PAGE = "invalid.html";
        
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException{
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String button = request.getParameter("btAction");
        String url = INVALID_PAGE;
        
        try{
            String username = request.getParameter("txtUsername");
            String password = request.getParameter("txtPassword");
            
            TemplateQuestion dao = new TemplateQuestion();
            boolean result = dao.checkLogin(username, password);
           
            
        }catch (SQLException ex) {
            ex.printStackTrace();
        }catch (NamingException ex){
            ex.printStackTrace();
        }
        finally{
            RequestDispatcher rd = request.getRequestDispatcher(url);
            rd.forward(request, response);
            out.close();
        }
    }
}
