package com.practicalexam.student;

import com.practicalexam.student.khanhkt.registration.RegistrationDAO;
import com.practicalexam.student.khanhkt.registration.RegistrationDTO;

import java.io.Serializable;

public class TemplateQuestion implements Serializable {

    public static boolean checkLogin(String username, String password) {

        RegistrationDAO dao = new RegistrationDAO();

        boolean check = false;
        try {
            // Call function

            check = dao.checkLogin(username, password);

            //
        } catch (Exception e) {
        }
        return check;
    }

    public static int searchByLastname(String lastname) {
        RegistrationDAO dao = new RegistrationDAO();
        int result = -1;
        try {
            // Student call function

            result = dao.searchLastname(lastname).size();

            //
        } catch (Exception e) {
        }
        return result;
    }

    public static boolean deleteAccount(String username) {
        RegistrationDAO dao = new RegistrationDAO();
        boolean check = false;
        try {
            // Student call function

            check = dao.deleteAccount(username);

            //
        } catch (Exception e) {
        }
        return check;
    }

    public static boolean insertAccount(String username, String password, String lastName, Boolean isAdmin) {
        RegistrationDAO dao = new RegistrationDAO();
        boolean check = false;
        try {

            // Student call function

            RegistrationDTO dto = new RegistrationDTO(username, password, lastName, isAdmin);
            check = dao.insertAccount(dto);

            //
        } catch (Exception e) {
        }
        return check;
    }

    public static boolean updateAccount(String username, String password, String lastName, Boolean isAdmin) {
        RegistrationDAO dao = new RegistrationDAO();
        boolean check = false;
        try {
            // Student call function

            RegistrationDTO dto = new RegistrationDTO(username, password, lastName, isAdmin);
            check = dao.updateAccount(dto);

            //
        } catch (Exception e) {
        }

        return check;
    }
}
