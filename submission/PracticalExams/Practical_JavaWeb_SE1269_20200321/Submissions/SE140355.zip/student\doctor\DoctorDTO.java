/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.practicalexam.student.doctor;

/**
 *
 * @author SE140355
 */
public class DoctorDTO {
    private String id;
    private String fullname;
    private String specialization;
    private String phoneNumber;
    private String address;
    private String password;
    private boolean leader;

    public DoctorDTO(String id, String fullname, String specialization, String phoneNumber, String address, String password, boolean leader) {
        this.id = id;
        this.fullname = fullname;
        this.specialization = specialization;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.password = password;
        this.leader = leader;
    }

    public DoctorDTO() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isLeader() {
        return leader;
    }

    public void setLeader(boolean leader) {
        this.leader = leader;
    }
    
    
}
