/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.scheduler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author SE140355
 */
public class SchedulerDAO {

    private Connection conn = null;
    private PreparedStatement stm = null;
    private ResultSet rs = null;

    public SchedulerDAO() {
    }

    public void closeConnection() throws SQLException {
        if (rs != null) {
            rs.close();
        }
        if (stm != null) {
            stm.close();
        }

        if (conn != null) {
            conn.close();
        }
    }
    
    private void search(String from, String to) throws SQLException {
        try {
            String sql = "select fullName, specialization, phoneNumber "
                    + "FROM tbl_Scheduler "
                    + "WHERE doctorId = ?";
        } finally {
            closeConnection();
        }
    }
}
