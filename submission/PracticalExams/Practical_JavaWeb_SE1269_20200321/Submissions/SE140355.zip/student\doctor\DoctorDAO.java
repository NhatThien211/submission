/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.doctor;

import com.practicalexam.student.connection.DBUtilities;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.naming.NamingException;

/**
 *
 * @author SE140355
 */
public class DoctorDAO {

    private Connection conn = null;
    private PreparedStatement stm = null;
    private ResultSet rs = null;

    public DoctorDAO() {
    }

    public void closeConnection() throws SQLException {
        if (rs != null) {
            rs.close();
        }
        if (stm != null) {
            stm.close();
        }

        if (conn != null) {
            conn.close();
        }
    }

    public boolean checkLogin(String username, String password)
            throws SQLException, NamingException, ClassNotFoundException {
        boolean result = false;
        try {
            String sql = "SELECT doctorId "
                    + "FROM tbl_Doctor "
                    + "WHERE doctorId = ? AND password = ?";
            conn = DBUtilities.makeConnection();
            stm = conn.prepareStatement(sql);
            stm.setString(1, username);
            stm.setString(2, password);
            rs = stm.executeQuery();

            if (rs.next()) {
                result = true;
            }
        } finally {
            closeConnection();
        }

        return result;
    }

    public DoctorDTO getFullName(String username) 
            throws SQLException, ClassNotFoundException, NamingException {
        DoctorDTO dto = null;
        try {
            String sql = "SELECT fullName "
                    + "FROM tbl_Doctor "
                    + "WHERE doctorId = ?";
            conn = DBUtilities.makeConnection();
            stm = conn.prepareStatement(sql);
            stm.setString(1, username);
            rs = stm.executeQuery();
            
            if (rs.next()) {
                dto = new DoctorDTO();
                dto.setFullname(rs.getString("fullName"));
            }
        } finally {
            closeConnection();
        }
        return dto;
    }
    
    private List<DoctorDTO> doctorList;
    
    private List<DoctorDTO> getDoctorList() {
        return doctorList;
    }
    
    
}
