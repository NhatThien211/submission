/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.practicalexam.student.scheduler;

import java.sql.Timestamp;

/**
 *
 * @author SE140355
 */
public class SchedulerDTO {

    private int id;
    private Timestamp shiftDate;
    private Timestamp fromTime;
    private Timestamp dateTime;
    private String discription;
    private String doctorId;

    public SchedulerDTO() {
    }

    public SchedulerDTO(int id, Timestamp shiftDate, Timestamp fromTime, Timestamp dateTime, String discription, String doctorId) {
        this.id = id;
        this.shiftDate = shiftDate;
        this.fromTime = fromTime;
        this.dateTime = dateTime;
        this.discription = discription;
        this.doctorId = doctorId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Timestamp getShiftDate() {
        return shiftDate;
    }

    public void setShiftDate(Timestamp shiftDate) {
        this.shiftDate = shiftDate;
    }

    public Timestamp getFromTime() {
        return fromTime;
    }

    public void setFromTime(Timestamp fromTime) {
        this.fromTime = fromTime;
    }

    public Timestamp getDateTime() {
        return dateTime;
    }

    public void setDateTime(Timestamp dateTime) {
        this.dateTime = dateTime;
    }

    public String getDiscription() {
        return discription;
    }

    public void setDiscription(String discription) {
        this.discription = discription;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }
    
    
}
