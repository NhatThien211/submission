/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.practicalexam.student.phuong.tbl_doctor;

import com.practicalexam.student.connection.DBUtilities;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.NamingException;

/**
 *
 * @author DELL
 */
public class Tbl_DoctorDAO implements Serializable {
    public boolean checkLogin(String username, String password) 
        throws NamingException, ClassNotFoundException, SQLException {
        Connection con = null;
        PreparedStatement pStm = null;
        ResultSet rs = null;
        boolean check = false;
        try {
            con = DBUtilities.makeConnection();
            if (con != null) {
                String query = "SELECT fullName FROM tbl_Doctor " +
                        "WHERE doctorId = ? AND password = ? AND leader = ?";
                pStm = con.prepareStatement(query);
                pStm.setString(1, username);
                pStm.setString(2, password);
                pStm.setBoolean(3, true);
                rs = pStm.executeQuery();
                if (rs.next()) {
                    check = true;
                    return check;
                }
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pStm != null) {
                pStm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return check;
    }
    
    public String getFullName(String username) 
        throws NamingException, ClassNotFoundException, SQLException {
        Connection con = null;
        PreparedStatement pStm = null;
        ResultSet rs = null;
        try {
            con = DBUtilities.makeConnection();
            if (con != null) {
                String query = "SELECT fullName FROM tbl_Doctor " +
                        "WHERE doctorId = ?";
                pStm = con.prepareStatement(query);
                pStm.setString(1, username);
                rs = pStm.executeQuery();
                if (rs.next()) {
                    System.out.println(rs.getString("fullName"));
                    return rs.getString("fullName");
                }
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pStm != null) {
                pStm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return null;
    }
}
