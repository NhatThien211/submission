package com.practicalexam.student;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author FPT University - HCMC Java OOP Practical Exam Template
 */
public class Cabinet {

    //StartList - do not remove this comment!!!
    // Declare ArrayList or Array here
    private Watch list[] = new Watch[100];
    //EndList - do not remove this comment!!!

    private Scanner scannerObj = new Scanner(System.in);
    private int count = 0;

    public void add() {
        // Print the object details after adding
        String id, name, manufacturer;
        double price;
        boolean check;
       do{
            System.out.print("Enter the watch's id: ");
            id = scannerObj.nextLine();
            check = checkDuplicatedId(id);
            if (check == true) {
                System.out.println("\tThis id existed");
            }
        } while(check == false);
        System.out.print("Enter the watch's name");
        name = scannerObj.nextLine();
        System.out.println("Enter the watch's manufacture");
        manufacturer = scannerObj.nextLine();
        System.out.println("Enter the watch's price");
        price = Double.parseDouble(scannerObj.nextLine());
        list[count] = new Watch(id, name, manufacturer, price);
        list[count].showProfice();
        count++;

    }

    public boolean checkDuplicatedId(String id) {
        // Your code here
        for (int i = 0; i < count; i++) {
            if (id.equals(list[i].getId())) {
                return true;
            }
        }
        return false;
    }

    public void update() {
        // Print the object details after updating name/model and price
        Watch x;
        String id;
        int pos;
        if (count == 0) {;
            System.out.println("Empty list.");
            return;
        }
        System.out.print("Enter the watch's id: ");
        id = scannerObj.nextLine().toUpperCase();
        pos = find(id);
        if (pos < 0) {
            System.out.println("Not found");
            return;
        } else {
            System.out.print("Enter the watch's new name: ");
            String name = scannerObj.nextLine();
            list[pos].setName(name);
            System.out.println("Enter the watch new price");
            double price = Double.parseDouble(scannerObj.nextLine());
            list[pos].setPrice(price);
            System.out.println("Updated!!!");
            x = list[pos];
            x.showProfice();
        }
    }

    public void search() {
        // Print the object details after searching
        String id;
        int pos;
        Watch x;
        if (count == 0) {
            System.out.println("Empty list");
            return;
        }
        System.out.print("Enter the watch's id: ");
        id = scannerObj.nextLine();
        pos = find(id);
        if (pos < 0) {
            System.out.println("Not found");
        } else {
            x = list[pos];
            x.showProfice();
        }
    }

    public void remove() {
        // Print the list after removing
        String id;
        int pos;
        if (count == 0) {
            System.out.println("Empty list");
            return;
        }
        System.out.print("Enter the watch's id: ");
        id = scannerObj.nextLine();
        pos = find(id);
        if (pos < 0) {
            System.out.println("Not found");
        } else {
            for (int i = pos; i < count - 1; i++) {
                list[i] = list[i + 1];
            }
            list[count - 1].showProfice();
            count--;
//            System.out.println("The watch was removed");
//            System.out.println("Here is the list");
//            for (int i = 0; i < count; i++) {
//                list[i].showProfice();
//            }
        }
    }

    public void sort() {
        // Print the object details after sorting
        for (int i = 0; i < count; i++) {
            for (int j = 0; j < 10; j++) {
                if (list[i].getName().compareTo(list[j].getName()) < 0) {

                }

            }
        }

    }

    public int find(String id) {
        if (count == 0) {
            System.out.println("Empty list");
            return -1;
        }
        for (int i = 0; i < count; i++) {
            if (id.equals(list[i].getId())) {
                return i;
            }
        }
        return -1;
    }
}
